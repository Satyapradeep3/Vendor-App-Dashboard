import React from 'react';
import { BrowserRouter, Route} from 'react-router-dom';
import './App.css';
import SignIn from './Auth/SignIn';
import SignUp from './Auth/SignUp';
import Dashboard from './Auth/Dashboard';


function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Route exact path='/' component={()=><SignUp/>}/>
        <Route path='/SignIn'  component={SignIn} />
        <Route path='/Dashboard'  component={Dashboard} />
      </BrowserRouter>
    </div>
  );
}

export default App;
